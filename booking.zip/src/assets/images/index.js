import bruschettaImg from "./bruschetta.jpg";
import lemonDessertImg from "./lemon-dessert.jpg";
import greekSaladImg from "./greek-salad.jpg";
import chefs1Img from "./chefs-mario-and-adrian_a.jpg";
import chefs2Img from "./chefs-mario-and-adrian_b.jpg";
import customer1Img from "./customer1.jpg";
import customer2Img from "./customer2.jpg";
import customer3Img from "./customer3.jpg";
import customer4Img from "./customer4.jpg";

export {
  bruschettaImg,
  lemonDessertImg,
  greekSaladImg,
  chefs1Img,
  chefs2Img,
  customer1Img,
  customer2Img,
  customer3Img,
  customer4Img,
};
