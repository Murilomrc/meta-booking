import Chicago from "./Chicago";
export default Chicago;
