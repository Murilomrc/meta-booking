import CustomerSayCard from "./CustomerSayCard";

export default CustomerSayCard;
