import CustomersSay from "./CustomersSay";

export default CustomersSay;
