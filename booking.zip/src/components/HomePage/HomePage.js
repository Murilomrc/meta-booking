import React from "react";

import Main from "../Main";

const HomePage = () => {
  return <Main />;
};

export default HomePage;
