import SpecialCard from "./SpecialCard";

export default SpecialCard;
